# Docker com streamlit

## Aplicativo: Conversor de OFX para XLSX
### Criado por: Ariel Reises
#### Empresa: Reises Co.
#### CNPJ: 57.975.327/0001-04
#### Contato: ariel@reises.com.br
#### Website: www.reises.com.br

## Uso exclusivo para: Movendo LTDA
### CNPJ: 51.265.918/0001-01
# ========================================
